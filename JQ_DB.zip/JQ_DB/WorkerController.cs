using system;
using system.collections.generic;
using system.linq;
using system.web;
using system.web.mvc;
using newtonsoft.json;
using jq_db.models;

namespace jq_db.controllers
{
    public class workercontroller : controller
    {
        private workerentities contextob;
        public workercontroller()
        {
            contextob = new workerentities();
        }

        public actionresult index()
        {
            return view();
        }

        public jsonresult getdata()
        {
            var c = contextob.workertables.tolist();
            if (c != null)
            {
                return json(c, jsonrequestbehavior.allowget);
            }
            else
            {
                return json(new workertable(), jsonrequestbehavior.allowget);
            }
        }
    }
}

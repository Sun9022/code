using Form_Tag_Helper.Models;
using Microsoft.AspNetCore.Mvc;

namespace Form_Tag_Helper.Controllers
{
    public class StudentController : Controller
    {
        [HttpGet]
        public IActionResult Form()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Form(Student student)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = "Registration Successful!";
                ViewBag.Data = student;
            }

            return View(student);
        }
    }
}

from sklearn.datasets import load_iris
x,y=load_iris(return_X_y=True)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split=train_test_split=train_test_split(x,y,test_size=0.2,random_state=80)

from sklearn.neighbors import KNeighborsClassifier
knn=KNeighborsClassifier(n_neighbors=4,metric='euclidean',weights='distance')
knn.fit(x_train,y_train)
y_pred=knn.predict(x_test)

from sklearn.metrics import accuracy_score
accuracy=accuracy_score(y_test,y_pred)
print(accuracy*100)
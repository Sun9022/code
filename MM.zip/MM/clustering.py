# 1)KMeans Clustering
from sklearn.datasets import load_iris
iris=load_iris()
x=iris.data

# also same as 2nd kMedoids clustering , pip install scikit-learn-extra
# from sklearn_extra.cluster import KMedoids
from sklearn.cluster import KMeans
km=KMeans(n_clusters=3)
km.fit(x)
print(km.labels_)
print(km.cluster_centers_)

labels=km.labels_
centroids=km.cluster_centers_

#cluster visualization
import matplotlib.pyplot as plt
plt.scatter(x[:,0],x[:,1],c=labels,cmap='plasma',label='Data points')
plt.scatter(centroids[:,0],centroids[:,1],c='red',marker='X',s=100,label='centroid')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.show()


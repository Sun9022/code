import pandas as pd
df=pd.read_excel('datasets/Transaction.xlsx')
print(df)

x=df.drop('TID',axis=1)
# print(x)

from mlxtend.frequent_patterns import apriori,association_rules
freq_patterns=apriori(x,min_support=.5)
# print(freq_patterns)

ass_rules=association_rules(freq_patterns,metric='confidence',min_threshold=.5)
print(ass_rules)
print(ass_rules[['antecedents','consequents','support','confidence']])

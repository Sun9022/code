#Que 1
import pandas as pd
import numpy as np

driver=pd.read_csv('datasets/driver-data.csv')
# print(driver)

X=driver.drop('id',axis=1)

from sklearn.cluster import KMeans
km=KMeans(n_clusters=3)
km.fit(X)

driver['cluster_type']=km.labels_
sse_per_cluster = {}
for i in range(3): 
    cluster_points = X[driver['cluster_type'] == i] 
    squared_distances =np.sum((cluster_points - km.cluster_centers_[i]) ** 2, axis=1)
    sse_per_cluster[i] = squared_distances.sum()

print("\nSum of Squared Errors (SSE) for each cluster:")
for i in range(3):
    print(f"Cluster {i}: {sse_per_cluster[i]}")
print(driver)



#Que2

# import numpy as np

# X=np.array([[1,3],[2,4],[6,2],[3,11],[5,10],[8,13],[10,23],[12,14],[14,19],[18,24],
#             [4,5],[21,25],[23,27],[6,8],[12,9],[10,7],[13,16],[5,8],[6,9],[8,11]])

# from sklearn.cluster import Birch
# b=Birch(threshold=5,branching_factor=3)
# b.fit(X)
# labels=b.labels_
# centroid=b.subcluster_centers_

# import matplotlib.pyplot as plt
# plt.scatter(X[:, 0], X[:, 1], c=labels, label='Data Points', cmap='Blues')
# plt.scatter(centroid[:, 0], centroid[:, 1], marker='X', label='Centroids', color='orange')
# plt.legend()
# plt.show()


#Que3
# Agglomerative Clustering
# import numpy as np

# X=np.array([[1],[4],[7],[10],[3],[9],[11],[5],[13],[16],[18],[26],[22],[15],[23]])
# print(X)

# from sklearn.cluster import AgglomerativeClustering
# from scipy.cluster.hierarchy import dendrogram,linkage
# ac=AgglomerativeClustering(distance_threshold=1,n_clusters=None)
# ac.fit(X)
# Z=linkage(X,method='complete')
# dendrogram(Z)

# import matplotlib.pyplot as plt
# plt.title("Dendrogram for Agglomerative Clustering")
# plt.xlabel("Sample Index")
# plt.ylabel("Distance")
# plt.show()


#Que 4
# DBSCAN Clustering
import pandas as pd

db_data=pd.read_excel('datasets/DBSCAN.xlsx')
print(db_data)

from sklearn.cluster import DBSCAN
db=DBSCAN(eps=2,min_samples=2)
db.fit(db_data)
print(db.labels_)

import matplotlib.pyplot as plt
plt.scatter(db_data['X'],db_data['Y'],c=db.labels_ ,label='Data Points')
plt.scatter(db_data['X'][db.labels_==-1],db_data['Y'][db.labels_==-1],c='red',
                                   label='Noise Points',marker='D')
plt.title('DBSCAN Clustering')
plt.xlabel('X')
plt.legend()
plt.ylabel('Y')
plt.show()


#Que5
# import pandas as pd

# ass_data=pd.read_excel('datasets/association.xlsx')
# # print(ass_data) 
# ass=ass_data.drop('TID',axis=1)

# from mlxtend.frequent_patterns import apriori,association_rules
# freq_patterns=apriori(ass,min_support=0.2,use_colnames=True)
# print(freq_patterns)

# ass_rules=association_rules(freq_patterns,metric='confidence',min_threshold=1)
# print(ass_rules[['antecedents','consequents','support','confidence']])

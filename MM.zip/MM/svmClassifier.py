import pandas as pd
weather=pd.read_excel('datasets/weather.xlsx')
print(weather)

from sklearn.preprocessing import OneHotEncoder,LabelEncoder
ohe=OneHotEncoder()
part=ohe.fit_transform(weather,[['outlook','windy']]).toarray()
df_part=pd.DataFrame(part,columns=ohe.get_feature_names_out())
df_final=pd.concat([df_part,weather],axis=1).drop(['outlook','windy'],axis=1)
print(df_final)

le=LabelEncoder()
df_final['play_Encoded']=le.fit_transform(df_final['play'])
df_final.drop('play',axis=1,inplace=True)
print(df_final)

x=df_final.drop('play_Encoded',axis=1)
y=df_final['play_Encoded']

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split=train_test_split=train_test_split(x,y,test_size=0.1)

from sklearn.svm import SVC
svmc=SVC(kernel='linear')
svmc.fit(x_train,y_train)
y_pred=svmc.predict(x_test)

from sklearn.metrics import accuracy_score
accuracy=accuracy_score(y_test,y_pred)
print(accuracy*100)

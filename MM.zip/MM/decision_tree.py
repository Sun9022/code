from sklearn.datasets import load_iris
x,y=load_iris(return_X_y=True)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split=train_test_split=train_test_split(x,y,test_size=0.3)

from sklearn.tree import DecisionTreeClassifier
dtc=DecisionTreeClassifier(criterion='entropy',max_depth=4,min_samples_split=60,max_leaf_nodes=5,min_samples_leaf=35)

dtc.fit(x_train,y_train)
y_pred=dtc.predict(x_test)

from sklearn.metrics import accuracy_score  
accuracy=accuracy_score(y_test,y_pred)
print(accuracy*100)

#Tree Visualization
import matplotlib.pyplot as plt
from sklearn.tree import plot_tree
plt.figure(figsize=(15,10),dpi=65,facecolor='lightgrey')
plot_tree(dtc,feature_names=load_iris().feature_names,class_names=load_iris().target_names,filled=True,rounded=True)

plt.show()



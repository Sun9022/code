#Text based feature eaxtraction

import pandas as pd
corpus=[
    "This is flower which is red",
    "That is chalk",
    "There is class"
    
]
from sklearn.feature_extraction.text import CountVectorizer
c_vector=CountVectorizer()
features=c_vector.fit_transform(corpus).toarray()
df_features=pd.DataFrame(features,columns=c_vector.get_feature_names_out())
print(df_features)


#Tfidf
from sklearn.feature_extraction.text import TfidfVectorizer
tfidf_vector=TfidfVectorizer()
features_wts=tfidf_vector.fit_transform(corpus).toarray()
df_features_wts=pd.DataFrame(features_wts,columns=tfidf_vector.get_feature_names_out())
print(df_features_wts)


#Normalization
import numpy as np
no_data=np.array([
    [1,2],
    [3,4],
    [5,6],
    [7,8],
])
#MinMaxScaler
from sklearn.preprocessing import MinMaxScaler
min_scaler=MinMaxScaler()
print(min_scaler.fit_transform(no_data))

#StandardScaler
from sklearn.preprocessing import StandardScaler
std_scaler=StandardScaler()
print(std_scaler.fit_transform(no_data))


#PCA=principle comp analysis

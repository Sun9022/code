namespace Dependency_injection.Models
{
    public interface InterEmployee
    {
        int GetTotalEmployees();
    }
}

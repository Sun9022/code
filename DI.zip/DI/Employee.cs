namespace Dependency_injection.Models
{
    public class Employee:InterEmployee
    {
        public int GetTotalEmployees()
        {
            return 10;
        }
    }
}
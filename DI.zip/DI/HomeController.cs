using Microsoft.AspNetCore.Mvc;
using Dependency_injection.Models;


namespace Dependency_injection.Controllers
{
    public class HomeController : Controller
    {
            private readonly InterEmployee _employee;
            private readonly InterStudent _student;

            public HomeController(InterEmployee employee, InterStudent student)
            {
                _employee = employee;
                _student = student;
            }

            public ActionResult Index()
            {
                ViewBag.TotalEmployees = _employee.GetTotalEmployees();
                ViewBag.TotalStudents = _student.GetTotalStudents();
                return View();
            }
        }
    }
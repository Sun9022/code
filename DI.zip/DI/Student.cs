namespace Dependency_injection.Models
{
    public class Student:InterStudent
    {
        public int GetTotalStudents()
        {
            return 20;
        }
    }
}
namespace Dependency_injection.Models
{
    public interface InterStudent
    {
        int GetTotalStudents();
    }
}
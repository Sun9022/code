<!--connection.php-->
<?php
require 'vendor/autoload.php';
$client = new MongoDB\Client("mongodb://localhost:27017");
$db = $client->selectDatabase("user_db");
$collection = $db->selectCollection("users");
?>

<!--index.php -->
<?php
require 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];

    $collection->insertOne(['name' => $name, 'email' => $email, 'age' => (int)$age]);
    header("Location: index.php");
    exit;
}
?>

<title>PHP MongoDB CRUD</title>
<body>
    <h1>PHP MongoDB CRUD</h1>
    <h2>User details</h2>
    <form method="post">
        <input type="text" name="name" placeholder="Name" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="number" name="age" placeholder="Age" required><br>
        <br>
        <button type="submit">Add User</button>
    </form>
 
    <h2>User List</h2>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>Actions</th>
        </tr>


        <?php
        $users = $collection->find();
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . $user['name'] . "</td>";
            echo "<td>" . $user['email'] . "</td>";
            echo "<td>" . $user['age'] . "</td>";

            echo "<td>
            <a href='update.php?id={$user['_id']}'>Edit</a> |
            <a href='delete.php?id={$user['_id']}' onclick='return confirm(\"Delete User?\")'>Delete</a>
        </td>";
            echo "</tr>";
        }
        
        ?>
    </table>
</body>
    

<!-- update.php-->
<?php
require 'connection.php';

$id = new MongoDB\BSON\ObjectId($_GET['id']);
$user = $collection->findOne(['_id' => $id]);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];

    $collection->updateOne(
        ['_id' => $id],
        ['$set' => ['name' => $name, 'email' => $email, 'age' => (int)$age]]
    );
    header("Location: index.php");
    exit;
}
?>

<title>Update</title>
<h2>Update User</h2>
<form method="post">
    Name: <input type="text" name="name" value="<?=$user['name']; ?>" required><br>
    Email: <input type="email" name="email" value="<?=$user['email']; ?>" required><br>
    Age: <input type="number" name="age" value="<?=$user['age']; ?>" required><br>
    <br>
    <button type="submit">Update</button>
    
</form>


<!--delete.php-->
<?php
require 'connection.php';

$id = new MongoDB\BSON\ObjectId($_GET['id']);
$collection->deleteOne(['_id' => $id]);
header("Location: index.php");
exit;
?>
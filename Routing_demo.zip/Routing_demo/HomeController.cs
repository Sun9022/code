using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;


namespace Routing_demo.Controllers;

   // Attribute Routing
    [Route("Home")]
public class HomeController : Controller
{
    [Route("")]
    [Route("index")]
    public IActionResult Index()
    {
        return Content("Welcome to the Home Page! (Attribute Routing)");
    }

    [Route("about")]
    public IActionResult About()
    {
        return Content("This is the About Page. (Attribute Routing)");
    }

    [Route("contact/{id}")]
    public IActionResult Contact(int id)
    {
        return Content($"Contact Page for ID: {id} (Attribute Routing)");
    }
}

// Convention-based Routing Example
public class DefaultController : Controller
{
    public IActionResult Index()
    {
        return Content("Welcome to the Home Page! (Convention Routing)");
    }

    public IActionResult About()
    {
        return Content("This is the About Page. (Convention Routing)");
    } 

    public IActionResult Contact(int id)
    {
        return Content($"Contact Page for ID: {id} (Convention Routing)");
    }
}

// Output:

// Attribute Routing:
// http://localhost:5000/Home          => Welcome to the Home Page! (Attribute Routing)
// http://localhost:5000/Home/index    => Welcome to the Home Page! (Attribute Routing)
// http://localhost:5000/Home/about    => This is the About Page. (Attribute Routing)
// http://localhost:5000/Home/contact/2 => Contact Page for ID: 2  (Attribute Routing)

// Convention-based Routing:
// http://localhost:5000/              => Welcome to the Home Page! (Convention Routing)
// http://localhost:5000/Default/About => This is the About Page. (Convention Routing)
// http://localhost:5000/Default/Contact/1 => Contact Page for ID: 1 (Convention Routing)

<?php
require 'vendor/autoload.php';

$client=new MongoDB\Client("mongodb://localhost:27017");

$db=$client->CRUDDB;
$collection=$db->products;

$insertResult=$collection->insertOne([
    'name'=>'Smartphone',
    'category'=>'Electronics',
    'price'=>50000,
    'stock'=>20
]);

$insertResult=$collection->insertMany([
    ['name' => 'uday','age'=>21],
    ['name' => 'mohan','age'=>23],
    ['name' => 'ram','age'=>28],
]);

echo "Inserted product ID:".$insertResult->getInsertedId()."\n";

//findOne
echo "Fetching the inserted product...\n";
$product=$collection->findOne(['name'=>'Smartphone']);
if ($product) {
    echo "Product found:\n";
    echo "Name:" .$product['name']."\n";
    echo "Price:" .$product['price']."\n"; 
    echo "Stock:" .$product['stock']."\n";
}
  
//UpdateOne
// echo "Updating product stock...\n";
// $updateResult = $collection->updateOne(
//         ['name' => 'Smartphone'],
//         ['$set' => ['price' => 2000]]
// );
// echo "Modified " . $updateResult->getModifiedCount() . " documents\n";


echo "Deleting the product...\n";
$deleteResult = $collection->deleteOne(['name' => 'Smartphone']);
echo "Deleted " . $deleteResult->getDeletedCount() . " documents\n";


echo "Fetching all students records:\n"."<br>";
$documents=$collection->find();
foreach($documents as $document){
    echo "ID:".$document['_id']."\n"."<br>";
    echo "Name:".$document['name']."\n"."<br>";
    echo "Age:".$document['age']."\n"."<br>";
}

?>
using jQueryPartialView.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace jQueryPartialView.Controllers
{
 public class HomeController : Controller
    {
        private static List<Item> Items = new List<Item>
        {
            new Item { Id = 1, Name = "Item 1", Price = 10.99m },
            new Item { Id = 2, Name = "Item 2", Price = 20.99m },
            new Item { Id = 3, Name = "Item 3", Price = 30.99m }
        };

        // Main page that will load the partial view dynamically
        public IActionResult Index()
        {
            return View();
        }

        // Action that returns the partial view with data
        public IActionResult GetItems()
        {
            return PartialView("_ItemList", Items);
        }
        public IActionResult UpdateItem(int id)
        {
            var item = Items.FirstOrDefault(x => x.Id == id);
            if (item != null)
            {
                item.Price += 5;  // Increase price for demonstration
            }
            return PartialView("_ItemList", Items);
        }
    }

}

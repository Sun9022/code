using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;//core 15
//using Microsoft.AspNetCore.Mvc;  core 22
using Data_annotation.Models;

namespace Data_annotation.Controllers
{
    public class ValidationController : Controller
    {

        public ActionResult Index()
        //public IActionResult Index()//core
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index (Register form)//dont change this in core
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = "Registration Successful!";
                ViewBag.Data = form;
            }
            
            return View(form);
        }
    }
}
    using Microsoft.EntityFrameworkCore;
    using Core_API.Models;

    var builder = WebApplication.CreateBuilder(args);

    builder.Services.AddDbContext<ProductDbContext>(options =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("dbcs"))); 

    // Add services to the container.
    builder.Services.AddControllers();

    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();

    var app = builder.Build();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }


    app.UseHttpsRedirection();  
    app.UseAuthorization();    

    app.MapControllers();

app.Run()


//Install this: Install-Package Swashbuckle.AspNetCore
//Install all packages related to DB first approach
//"launchBrowser": true,  it is by default false
//in controller & program.cs file showing "productDBContext " then click on tubelight -> show potential issue ->select last option
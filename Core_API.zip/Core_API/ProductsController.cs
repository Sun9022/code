using Microsoft.AspNetCore.Mvc;
using Core_API.Models;
using System.Linq;

namespace Core_API.Controllers    // Tbl name: Products
{
    [Route("api/[controller]")] 
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private ProductDbContext _context = new ProductDbContext();

        
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_context.Products.ToList());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null)
                return NotFound("Product Not Found");
            return Ok(product);
        }

        [HttpPost]
        public IActionResult Add(Product product)
        {
            _context.Products.Add(product);
            _context.SaveChanges();
            return Ok("Product Added Successfully");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Product product)
        {
            if (id != product.Id)
                return BadRequest("Product ID Mismatch");

            _context.Products.Update(product);
            _context.SaveChanges();
            return Ok("Product Updated Successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null)
                return NotFound("Product Not Found");

            _context.Products.Remove(product);
            _context.SaveChanges();
            return Ok("Product Deleted Successfully");
        }
    }
}
